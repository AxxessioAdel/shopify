import dotenv from "dotenv";
import fetch from "node-fetch";
dotenv.config();

const CONTENT_TYPE = process.env.CONTENT_TYPE;
const CUSTOM_CHECKOUT_APP_TOKEN = process.env.CUSTOM_CHECKOUT_APP_TOKEN;

const isDebugLevelInfo = process.env.DEBUG_LEVEL === "info";
if (isDebugLevelInfo) {
  console.log("[Debug] Shopify API Client loaded with debug level info");
  console.log("[Debug] CONTENT_TYPE:", CONTENT_TYPE);
  console.log("[Debug] CUSTOM_CHECKOUT_APP_TOKEN:", CUSTOM_CHECKOUT_APP_TOKEN);
}

export async function createCart() {
  const query = `
    mutation {
      cartCreate {
        cart {
          id
          createdAt
        }
      }
    }
  `;
  const body = JSON.stringify({ query });
  console.log("[createCart] Request body:", body);
  const response = await fetch(
    "https://vrr7x3-ab.myshopify.com/api/2024-04/graphql.json",
    {
      method: "POST",
      headers: {
        "Content-Type": CONTENT_TYPE,
        "X-Shopify-Storefront-Access-Token": CUSTOM_CHECKOUT_APP_TOKEN,
      },
      body,
    }
  );
  const data = await response.json();
  if (!data.data || !data.data.cartCreate || !data.data.cartCreate.cart) {
    console.error("Shopify createCart error response:", data);
    throw new Error(
      data.errors?.[0]?.message ||
        data.errors ||
        "Fehler beim Erstellen des Warenkorbs (createCart)."
    );
  }
  return data.data.cartCreate.cart;
}

export async function addProductToCart(cartId, merchandiseId, attributes = []) {
  const query = `
    mutation cartLinesAdd($cartId: ID!, $lines: [CartLineInput!]!) {
      cartLinesAdd(cartId: $cartId, lines: $lines) {
        cart {
          id
        }
        userErrors {
          field
          message
        }
      }
    }
  `;
  const variables = {
    cartId,
    lines: [
      {
        merchandiseId,
        quantity: 1,
        attributes,
      },
    ],
  };
  const body = JSON.stringify({ query, variables });
  console.log("[addProductToCart] Request body:", body);
  const response = await fetch(
    "https://vrr7x3-ab.myshopify.com/api/2024-04/graphql.json",
    {
      method: "POST",
      headers: {
        "Content-Type": CONTENT_TYPE,
        "X-Shopify-Storefront-Access-Token": CUSTOM_CHECKOUT_APP_TOKEN,
      },
      body,
    }
  );
  const data = await response.json();
  if (!data.data || !data.data.cartLinesAdd || !data.data.cartLinesAdd.cart) {
    console.error("Shopify addProductToCart error response:", data);
    throw new Error(
      data.errors?.[0]?.message ||
        data.errors ||
        "Fehler beim Hinzufügen zum Warenkorb (addProductToCart)."
    );
  }
  return data.data.cartLinesAdd.cart;
}

export async function getCheckoutUrl(cartId) {
  const query = `
    query getCart($cartId: ID!) {
      cart(id: $cartId) {
        checkoutUrl
      }
    }
  `;
  const variables = { cartId };
  const body = JSON.stringify({ query, variables });
  console.log("[getCheckoutUrl] Request body:", body);
  const response = await fetch(
    "https://vrr7x3-ab.myshopify.com/api/2024-04/graphql.json",
    {
      method: "POST",
      headers: {
        "Content-Type": CONTENT_TYPE,
        "X-Shopify-Storefront-Access-Token": CUSTOM_CHECKOUT_APP_TOKEN,
      },
      body,
    }
  );
  const data = await response.json();
  if (!data.data || !data.data.cart || !data.data.cart.checkoutUrl) {
    console.error("Shopify getCheckoutUrl error response:", data);
    throw new Error(
      data.errors?.[0]?.message ||
        data.errors ||
        "Fehler beim Abrufen der Checkout-URL."
    );
  }
  return data.data.cart.checkoutUrl;
}
